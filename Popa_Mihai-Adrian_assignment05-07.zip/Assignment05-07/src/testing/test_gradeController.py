from unittest import TestCase


class TestGradeController(TestCase):
    def test_give_assignment(self):
        pass

    def test_give_assignment_to_group(self):
        pass

    def test_retrieve_ungraded_assignments_by_student(self):
        pass

    def test_retrieve_students_by_assignment(self):
        pass

    def test_grade_student(self):
        pass

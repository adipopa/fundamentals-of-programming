from unittest import TestCase


class TestStudentController(TestCase):
    def test_create_student(self):
        pass

    def test_update_student(self):
        pass

    def test_delete_student(self):
        pass

    def test_retrieve_students(self):
        pass

    def test_retrieve_students_by_group(self):
        pass
